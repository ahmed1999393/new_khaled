<!DOCTYPE html>
<html lang="en-us">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title><?php echo htmlspecialchars(($seoTitle !== "") ? $seoTitle : "About"); ?></title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1200" />
		<meta name="description" content="<?php echo htmlspecialchars(($seoDescription !== "") ? $seoDescription : ""); ?>" />
	<meta name="keywords" content="<?php echo htmlspecialchars(($seoKeywords !== "") ? $seoKeywords : ""); ?>" />
		<!-- Facebook Open Graph -->
	<meta property="og:title" content="<?php echo htmlspecialchars(($seoTitle !== "") ? $seoTitle : "About"); ?>" />
	<meta property="og:description" content="<?php echo htmlspecialchars(($seoDescription !== "") ? $seoDescription : ""); ?>" />
	<meta property="og:image" content="<?php echo htmlspecialchars(($seoImage !== "") ? "{{base_url}}".$seoImage : ""); ?>" />
	<meta property="og:type" content="article" />
	<meta property="og:url" content="{{curr_url}}" />
	<!-- Facebook Open Graph end -->
		
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-3.5.1.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js?v=20210610203632" type="text/javascript"></script>

	<link href="css/font-awesome/font-awesome.min.css?v=4.7.0" rel="stylesheet" type="text/css" />
	<link href="css/site.css?v=20210610203630" rel="stylesheet" type="text/css" id="wb-site-stylesheet" />
	<link href="css/common.css?ts=1623409883" rel="stylesheet" type="text/css" />
	<link href="css/2.css?ts=1623409883" rel="stylesheet" type="text/css" id="wb-page-stylesheet" />
	<ga-code/>
	<script type="text/javascript">
	window.useTrailingSlashes = true;
</script>
	
	<link href="css/flag-icon-css/css/flag-icon.min.css" rel="stylesheet" type="text/css" />	
	<!--[if lt IE 9]>
	<script src="js/html5shiv.min.js"></script>
	<![endif]-->

	</head>


<body class="site <?php if (isset($wbPopupMode) && $wbPopupMode) echo ' popup-mode'; ?> " <?php if (isset($wbLandingPage) && $wbLandingPage) echo ' data-landing-page="'.$wbLandingPage.'"'; ?>><div class="root"><div class="vbox wb_container" id="wb_header">
	
<div class="wb_cont_inner"><div id="wb_element_instance22" class="wb_element wb-menu" data-plugin="Menu"><ul class="hmenu" dir="ltr"><li><a href="" target="_self">Home</a></li><li class="active"><a href="About/" target="_self">About</a></li><li><a href="Contacts/" target="_self">Contacts</a></li><li><a href="development/" target="_self">development</a></li></ul><div class="clearfix"></div></div><div id="wb_element_instance23" class="wb_element wb_element_picture" data-plugin="Picture" title=""><img alt="" src="gallery_gen/a07ae6af28e7e4a89a2957f99fcf1f2e_580x963.8571845896.png"></div></div><div class="wb_cont_outer"></div><div class="wb_cont_bg"></div></div>
<div class="vbox wb_container" id="wb_main">
	
<div class="wb_cont_inner"><div id="wb_element_instance25" class="wb_element wb_element_picture" data-plugin="Picture" title=""><img alt="" src="gallery_gen/f92bb3bd9e0bdf4efbe59b576b1b3f32.jpg"></div><div id="wb_element_instance26" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><h4 class="wb-stl-pagetitle"><strong>Name    : KHaled gamal mahmoud fatahalla  Elsakhawy</strong></h4>

<h4 class="wb-stl-pagetitle"><strong>Gender : male</strong></h4>

<h4 class="wb-stl-pagetitle"><strong>EMail    : Khaled20457@feng.bu.edu.eg</strong></h4>

<h4 class="wb-stl-pagetitle"><strong>ID           : 293</strong></h4>

<h4 class="wb-stl-pagetitle"> </h4>

<h4 class="wb-stl-pagetitle"> </h4>
</div><div id="wb_element_instance27" class="wb_element wb_element_picture" data-plugin="Picture" title=""><img alt="" src="gallery_gen/d24f4d916a4ca6f211b229338ecba086.jpg"></div><div id="wb_element_instance28" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><h1 class="wb-stl-heading1">About us</h1></div><div id="wb_element_instance29" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><h2 class="wb-stl-heading2">Creative designer</h2>
</div><div id="wb_element_instance30" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><h2 class="wb-stl-heading2">Professional application</h2></div></div><div class="wb_cont_outer"></div><div class="wb_cont_bg"></div></div>
<div class="vbox wb_container" id="wb_footer">
	
<div class="wb_cont_inner" style="height: 134px;"><div id="wb_element_instance24" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-footer">© 2021 Khaled-elsakhawy.com</p>
</div><div id="wb_element_instance31" class="wb_element" data-plugin="" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer, #wb_footer .wb_cont_inner");
					footer.css({height: ""});
				}
			});
			</script></div></div><div class="wb_cont_outer"></div><div class="wb_cont_bg"></div></div><div class="wb_sbg"></div></div>{{hr_out}}</body>
</html>
