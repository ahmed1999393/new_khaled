<!DOCTYPE html>
<html lang="en-us">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title><?php echo htmlspecialchars(($seoTitle !== "") ? $seoTitle : "Home"); ?></title>
	<base href="{{base_url}}" />
			<meta name="viewport" content="width=1200" />
		<meta name="description" content="<?php echo htmlspecialchars(($seoDescription !== "") ? $seoDescription : ""); ?>" />
	<meta name="keywords" content="<?php echo htmlspecialchars(($seoKeywords !== "") ? $seoKeywords : ""); ?>" />
		<!-- Facebook Open Graph -->
	<meta property="og:title" content="<?php echo htmlspecialchars(($seoTitle !== "") ? $seoTitle : "Home"); ?>" />
	<meta property="og:description" content="<?php echo htmlspecialchars(($seoDescription !== "") ? $seoDescription : ""); ?>" />
	<meta property="og:image" content="<?php echo htmlspecialchars(($seoImage !== "") ? "{{base_url}}".$seoImage : ""); ?>" />
	<meta property="og:type" content="article" />
	<meta property="og:url" content="{{curr_url}}" />
	<!-- Facebook Open Graph end -->
		
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<script src="js/jquery-3.5.1.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js?v=20210610203632" type="text/javascript"></script>

	<link href="css/font-awesome/font-awesome.min.css?v=4.7.0" rel="stylesheet" type="text/css" />
	<link href="css/site.css?v=20210610203630" rel="stylesheet" type="text/css" id="wb-site-stylesheet" />
	<link href="css/common.css?ts=1623409883" rel="stylesheet" type="text/css" />
	<link href="css/1.css?ts=1623409883" rel="stylesheet" type="text/css" id="wb-page-stylesheet" />
	<ga-code/>
	<script type="text/javascript">
	window.useTrailingSlashes = true;
</script>
	
	<link href="css/flag-icon-css/css/flag-icon.min.css" rel="stylesheet" type="text/css" />	
	<!--[if lt IE 9]>
	<script src="js/html5shiv.min.js"></script>
	<![endif]-->

	</head>


<body class="site <?php if (isset($wbPopupMode) && $wbPopupMode) echo ' popup-mode'; ?> " <?php if (isset($wbLandingPage) && $wbLandingPage) echo ' data-landing-page="'.$wbLandingPage.'"'; ?>><div class="root"><div class="vbox wb_container" id="wb_header">
	
<div class="wb_cont_inner"><div id="wb_element_instance0" class="wb_element wb-menu" data-plugin="Menu"><ul class="hmenu" dir="ltr"><li class="active"><a href="" target="_self">Home</a></li><li><a href="About/" target="_self">About</a></li><li><a href="Contacts/" target="_self">Contacts</a></li><li><a href="development/" target="_self">development</a></li></ul><div class="clearfix"></div></div><div id="wb_element_instance1" class="wb_element wb_element_picture" data-plugin="Picture" title=""><img alt="" src="gallery_gen/a07ae6af28e7e4a89a2957f99fcf1f2e_580x963.8571845896.png"></div><div id="wb_element_instance3" class="wb_element wb_element_picture" data-plugin="Picture" title=""><img alt="" src="gallery_gen/e3a2c25700094092ef206cb93bcf7ab8.png"></div><div id="wb_element_instance4" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><h2 class="wb-stl-heading2"><span class="wb-stl-highlight">Mobile applications</span></h2></div></div><div class="wb_cont_outer"></div><div class="wb_cont_bg"></div></div>
<div class="vbox wb_container" id="wb_main">
	
<div class="wb_cont_inner"><div id="wb_element_instance5" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><h1 class="wb-stl-heading1">Mobile news</h1></div><div id="wb_element_instance6" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><h3 class="wb-stl-heading3" style="text-align: center;"><a href="">Mobile security</a></h3></div><div id="wb_element_instance7" class="wb_element wb_element_picture" data-plugin="Picture" title=""><img alt="" src="gallery_gen/f7840764475c2376a5c012f0a8692c7d.png"></div><div id="wb_element_instance8" class="wb_element wb_element_picture" data-plugin="Picture" title=""><img alt="" src="gallery_gen/36be9714c33e6b27b166efccfb662ab4.png"></div><div id="wb_element_instance9" class="wb_element wb_element_picture" data-plugin="Picture" title=""><img alt="" src="gallery_gen/05da5481b18b2e92409e8161821cb826.png"></div><div id="wb_element_instance10" class="wb_element wb_element_picture" data-plugin="Picture" title=""><img alt="" src="gallery_gen/e6af7ea03a493b316145e3fef8163347.png"></div><div id="wb_element_instance11" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><h3 class="wb-stl-heading3" style="text-align: center;"><a href="">Time planner</a></h3></div><div id="wb_element_instance12" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><h3 class="wb-stl-heading3" style="text-align: center;"><a href="">Personal adviser</a></h3></div><div id="wb_element_instance13" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><h3 class="wb-stl-heading3" style="text-align: center;"><a href="">Easy work</a></h3></div><div id="wb_element_instance14" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-normal" style="text-align: center;">In 2009, technology columnist David Pogue stated that smartphones could be nicknamed "app phones" to distinguish them from earlier less-sophisticated smartphones.[1] The term "app", short for "software application", has since become very popular; in 2010, it was listed as "Word of the Year" by the American Dialect Society</p>
</div><div id="wb_element_instance15" class="wb_element wb_element_picture" data-plugin="Picture" title=""><img alt="" src="gallery_gen/46764041b13204d650b6ddae25c76d0e_800x664.jpg"></div><div id="wb_element_instance16" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><h3 class="wb-stl-heading3" style="text-align: center;">Most mobile devices are sold with several apps bundled as pre-installed software, such as a web browser, email client, calendar, mapping program, and an app for buying music, other media, or more apps</h3>
</div><div id="wb_element_instance17" class="wb_element wb_element_picture" data-plugin="Picture" title=""><img alt="" src="gallery_gen/2216d73b403e99b5a032f9a9a97525c5_880x800.jpg"></div><div id="wb_element_instance18" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><h1 class="wb-stl-heading1">News</h1></div><div id="wb_element_instance19" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><h2 class="wb-stl-heading2">Help center</h2></div><div id="wb_element_instance20" class="wb_element wb-elm-orient-horizontal" data-plugin="Line"><div class="wb-elm-line"></div></div></div><div class="wb_cont_outer"></div><div class="wb_cont_bg"></div></div>
<div class="vbox wb_container" id="wb_footer">
	
<div class="wb_cont_inner" style="height: 134px;"><div id="wb_element_instance2" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-footer">© 2021 Khaled-elsakhawy.com</p>
</div><div id="wb_element_instance21" class="wb_element" data-plugin="" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer, #wb_footer .wb_cont_inner");
					footer.css({height: ""});
				}
			});
			</script></div></div><div class="wb_cont_outer"></div><div class="wb_cont_bg"></div></div><div class="wb_sbg"></div></div>{{hr_out}}</body>
</html>
